x = int(input('Digite um valor: '))
y = int(input('Digite outro valor: '))

z = x + y

print('Saida de z: ',z)