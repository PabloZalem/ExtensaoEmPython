x = 10

if(x < 30):
    x += 1
elif(x != 30):
    x += 3
else:
    print('nenhuma das opcoes')
    