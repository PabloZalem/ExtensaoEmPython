'''
2.	Faça um programa que receba o ano de nascimento de uma pessoa, o ano atual e imprima:
a.	A idade da pessoa no ano atual
b.	A idade que a pessoa terá em 2050
'''

x = int(input('Informe sua idade: '))
print('Idade no ano atual: ', 2023 - 1998)
print('Idade no ano de 2050: ', 2050 - 1998)