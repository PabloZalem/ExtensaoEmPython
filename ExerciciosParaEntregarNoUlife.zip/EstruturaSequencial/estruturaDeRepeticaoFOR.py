#impressao dos numeros
for i in range(1,11):
    print(i)

#impressao dos numero pares
for o in range(2,11,2):
    print(o)

#impressao dos caracteres
nome = "PABLO"
for c in nome:
    print(c)