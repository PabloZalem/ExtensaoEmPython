x = 10
y = 20

print(x)
print('O valor de y:' + str(y))
print('O valor de x %r e o valor de y %r' %(x,y))