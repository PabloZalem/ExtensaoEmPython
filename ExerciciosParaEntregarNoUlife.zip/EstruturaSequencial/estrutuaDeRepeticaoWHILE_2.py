x = 1
y = 10

while (y > x):
    print('O valor de y é ', y)
    y -= 2

print('O valor de y depois que saiu do loop: ', y)