a = 12
b = 23.3

print('valor de a: ', a)
print('valor de b: ', b)
print('A soma de a com b: ', a+b)
