lista = [10, 20, 30, 30, 30, 40, 10, 20]

# Removendo todas as ocorrências do número 30
lista = [x for x in lista if x != 30]

# Imprimindo a lista atualizada
print(lista)
