n1 = int(input("Informe o primeiro valor"))
n2 = int(input("Infome o segundo valor"))

if n1 > n2:
    print("o primeiro é maior que o segundo")
else:
    print("O segundo é maior que o primeiro")