for i in range(5):
    valor = float(input("Digite um valor: "))
    dobro = valor * 2
    print("O dobro de", valor, "é", dobro)
